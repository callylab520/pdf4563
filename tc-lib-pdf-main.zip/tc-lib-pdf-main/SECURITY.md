# Security Policy

## Reporting a Vulnerability

Please report (suspected) security vulnerabilities to info@tecnick.com.
